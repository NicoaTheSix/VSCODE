import torch
from torch import nn,optim
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("C:/Users/user/Desktop/pokemon.csv", header = 0)

x = np.array(df["cp"])
y = np.array(df["cp_new"])
x = np.reshape(x, (x.size, 1))
y = np.reshape(y, (y.size, 1))
x = x.astype(np.float32)
y = y.astype(np.float32)
x = torch.tensor(x)
y = torch.tensor(y)

class regression(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        x = self.linear(x)

        return x
    
model = regression(1, 1)
opt = optim.Adagrad(model.parameters(), lr = 0.1)
loss_f = nn.MSELoss() #loss function

epoch = 2000
losses = []

for i in range(epoch):
    pred = model(x)
    loss = loss_f(y, pred)
    losses.append(loss.item())

    loss.backward()
    opt.step()
    opt.zero_grad()

    if i % 10 == 0:
        print("epoch: {}/{}, loss:{:.6f}".format(i, epoch, loss))

z = model(x).detach().numpy()  # 把 model 轉成numpy型態畫圖

plt.figure(1)
plt.plot(losses)
plt.title("loss")
plt.xlabel("epoch")
plt.ylabel("loss")

plt.figure(2)
plt.plot(x, y, 'ro')
plt.plot(x, z, 'b')
plt.title('data')
plt.xlabel('cp')
plt.ylabel('new_cp')
plt.show()